/**
 * WEB222 – Assignment 05
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       <Preeya Surisai>
 *      Student ID: <180121238>
 *      Date:       <July 15 2024>
 */

/*******************************************************************************************
 * check the image function to display in the correct way. Working on tonight./
 * ********************************************************************************************/
// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { artists, songs } = window;

// For debugging, display all of our data in the console.
console.log({ artists, songs }, "App Data");
document.addEventListener("DOMContentLoaded", function () {
  const menu = document.getElementById("menu");
  const artistNameElement = document.getElementById("artist-name");
  const artistLinksElement = document.getElementById("artist-links");
  const songListBody = document.getElementById("song-list-body");

  function createArtistButtons() {
    artists.forEach((artist) => {
      const button = document.createElement("button");
      button.textContent = artist.name;
      button.addEventListener("click", () => showArtistInfo(artist));
      menu.appendChild(button);
    });
  }

  function showArtistInfo(artist) {
    artistNameElement.textContent = artist.name;
    artistLinksElement.innerHTML = "";

    const artistLinks = artist.urls
      .map((link) => `<a href="${link.url}" target="_blank">${link.name}</a>`)
      .join(", ");
    artistLinksElement.innerHTML = `(${artistLinks})`;

    const filteredSongs = songs.filter(
      (song) => song.artistId === artist.artistId && !song.explicit
    );

    songListBody.innerHTML = "";
    filteredSongs.forEach((song) => {
      const card = createSongCard(song);
      songListBody.appendChild(card);
    });
  }

  function createSongCard(song) {
    // Create a <div> to hold the card
    const card = document.createElement("div");
    card.classList.add("card");

    // Create a song image, use the .card-image class
    const songImg = document.createElement("img");

    songImg.src = song.imageURL;
    songImg.alt = `Image of ${song.title}`;
    songImg.classList.add("card-image");
    songImg.addEventListener("click", () => {
      window.open(song.url, "_blank");
    });
    card.appendChild(songImg);

    // Create song title element
    const songTitle = document.createElement("h3");
    songTitle.classList.add("card-title");
    songTitle.textContent = song.title;
    card.appendChild(songTitle);

    // Create song year element
    const songYear = document.createElement("time");
    songYear.classList.add("card-year");
    songYear.textContent = song.year;
    card.appendChild(songYear);

    // Create song duration element
    const songDuration = document.createElement("span");
    songDuration.classList.add("card-duration");
    songDuration.textContent = convertSecondsToMinutes(song.duration);
    card.appendChild(songDuration);

    return card;
  }

  function convertSecondsToMinutes(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
  }

  createArtistButtons();
});
